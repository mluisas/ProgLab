n = int(input())
matrix = []
adj = []
colored = [None for i in range(n)]
colors = 0
for i in range(n):
    matrix.append(list(map(int, input().split())))
for i in range(n):
    adj.append((i, sum(matrix[i])))
adj.sort(key=lambda s: s[1], reverse=True)
while None in colored:
    vertice = adj[0][0]
    colored[vertice] = colors
    adj.pop(0)
    temp = [i for i in range(n) if matrix[vertice][i] == 1]
    for k in adj:
        j = k[0]
        if colored[j] == None and j not in temp:
            colored[j] = colors
            adj.remove((j, sum(matrix[j])))
            for w in range(n):
                if matrix[j][w] == 1:
                    temp.append(w)
    colors += 1
print(colors)